/***********************************************************
        Copyright 1991,1994 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/


#ifndef SABER
#ifndef LINT
static char rcs_id[] = "$Id: Collection_TargetSourceFromFSImage.c,v 1.6 2004/02/04 22:24:06 cg2v Exp $";
#endif /* LINT */
#endif /* SABER */

/*
 * Author: Sohan C. Ramakrishna Pillai
 */

#include "depotlib.h"

#include "util.h"
#include "DepotErrorCodes.h"
#include "Hint.h"
#include "File.h"
#include "FileSystemImage.h"
#include "DepotConf.h"
#include "TargetDB.h"
#include "Collection.h"


TARGETSOURCE *
Collection_TargetSourceFromFSImage(fsimagenodep,
				   source,
				   collectionp)
     FILESYSTEMIMAGE *fsimagenodep;
     char *source;
     COLLECTION *collectionp;
{
  unsigned update_spec;
  short type;
  char *link_val = NULL;

  TARGETSOURCE *targetsourcep = NULL;

  if (fsimagenodep == NULL) {
    FatalError(DEPOT_BADFSIMAGENODE,
	       "Attempt to get targetsource from NULL file system image.\n");
  }
  if (source == NULL) {
    FatalError(DEPOT_BADTARGETSOURCEPATH,
	       "Attempt to create targetsource with NULL source path.\n");
  }
  if (collectionp == NULL) {
    FatalError(DEPOT_NULLCOLLECTION,
	       "Attempt to create target source for NULL collection.\n");
  }
  if (PROGRAM_ErrorNo == OK) {
    if (FILESYSTEMIMAGE_Type(fsimagenodep) & FS_REG) {
      update_spec = (U_MAP | COLLECTION_MapMethod(collectionp));
      type = F_REG;
    } else if (FILESYSTEMIMAGE_Type(fsimagenodep) & FS_HARDLNK) {
      update_spec = (U_MAP | COLLECTION_MapMethod(collectionp));
      type = F_REG;
    } else if (FILESYSTEMIMAGE_Type(fsimagenodep) & FS_SYMLNK) {
      update_spec = (U_MAP | COLLECTION_MapMethod(collectionp));
      type = F_LNK;
      link_val = FILESYSTEMIMAGE_Link(fsimagenodep);
    } else if (FILESYSTEMIMAGE_Type(fsimagenodep) & FS_DIR) {
      update_spec = (U_MKDIR | COLLECTION_MapMethod(collectionp));
      type = F_DIR;
    } else {
      FatalError(DEPOT_BADFSIMAGETYPE,
		 "Cannot get source from fsimagenode of unknown type.\n");
    }
  }
  if (PROGRAM_ErrorNo == OK) {
    FILESTAT filestat;
    FILESTAT_Type(&filestat) = type;
    FILESTAT_Mode(&filestat) = FILESYSTEMIMAGE_Mode(fsimagenodep);
    FILESTAT_NLinks(&filestat) = 0; /* insufficient information */
    FILESTAT_Uid(&filestat) = FILESYSTEMIMAGE_Uid(fsimagenodep);
    FILESTAT_Gid(&filestat) = FILESYSTEMIMAGE_Gid(fsimagenodep);
    FILESTAT_Size(&filestat) = FILESYSTEMIMAGE_Size(fsimagenodep);
    FILESTAT_MTime(&filestat) = FILESYSTEMIMAGE_MTime(fsimagenodep);
    FILESTAT_INode(&filestat) = 0; /* insufficient information */
    targetsourcep = TargetSource_Create(source,
					update_spec,
					COLLECTION_Id(collectionp),
					S_NULL,
					U_NULL /* update_spec_old */ ,
					NULL   /* secondary_source */ ,
					&filestat,
					link_val);
  }
  return (PROGRAM_ErrorNo == OK) ? targetsourcep : NULL;
}

/* $Source: /afs/andrew.cmu.edu/system/src/local/depot2/032/lib/Collection/RCS/Collection_TargetSourceFromFSImage.c,v $ */
