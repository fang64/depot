/***********************************************************
        Copyright 1991,1994 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/


#ifndef SABER
#ifndef LINT
static char rcs_id[] = "$Id: SourceUtil.c,v 1.6 2004/02/04 22:24:06 cg2v Exp $";
#endif /* LINT */
#endif /* SABER */

/*
 * Author: Sohan C. Ramakrishna Pillai
 */

#include "depotlib.h"

#include "util.h"
#include "DepotErrorCodes.h"
#include "File.h"
#include "TargetDB.h"



TARGETSOURCE *
TargetSource(targetsourcep)
     TARGETSOURCE *targetsourcep;
{
  TARGETSOURCE *newsourcep;

  if (targetsourcep == NULL) {
    FatalError(DEPOT_BADTARGETSOURCE,
	       "Attempt to to recreate NULL targetsource.\n");
  }
  if (PROGRAM_ErrorNo == OK)
    newsourcep = (TARGETSOURCE *) emalloc(sizeof(TARGETSOURCE));
  if (PROGRAM_ErrorNo == OK) {
    TARGETSOURCE_Path(newsourcep)
      = String(TARGETSOURCE_Path(targetsourcep),
	       strlen(TARGETSOURCE_Path(targetsourcep)));
    /* no error check here?  -dkindred */
    TARGETSOURCE_UpdateSpec(newsourcep)
      = TARGETSOURCE_UpdateSpec(targetsourcep);
    TARGETSOURCE_CollectionId(newsourcep)
      = TARGETSOURCE_CollectionId(targetsourcep);
    TARGETSOURCE_Status(newsourcep) = TARGETSOURCE_Status(targetsourcep);
    TARGETSOURCE_OldUpdateSpec(newsourcep)
      = TARGETSOURCE_OldUpdateSpec(targetsourcep);
    TARGETSOURCE_SecondarySource(newsourcep)
      = (TARGETSOURCE_SecondarySource(targetsourcep) == NULL) ?
      NULL : TargetSource(TARGETSOURCE_SecondarySource(targetsourcep));
    TARGETSOURCE_LinkValCache(newsourcep)
      = (TARGETSOURCE_LinkValCache(targetsourcep) == NULL) ?
      NULL : String(TARGETSOURCE_LinkValCache(targetsourcep), 
		    strlen(TARGETSOURCE_LinkValCache(targetsourcep)));
    if (PROGRAM_ErrorNo == OK) {
      TARGETSOURCE_StatCache(newsourcep) = NULL;
      if (TARGETSOURCE_StatCache(targetsourcep) != NULL) {
	TARGETSOURCE_StatCache(newsourcep)
	  = (FILESTAT *) emalloc(sizeof(FILESTAT));
	if (PROGRAM_ErrorNo == OK) {
	  memcpy(TARGETSOURCE_StatCache(newsourcep), 
		 TARGETSOURCE_StatCache(targetsourcep), 
		 sizeof(FILESTAT));
	} else {
	  TargetSource_Free(newsourcep);
	}
      }
    }
  }
  return (PROGRAM_ErrorNo == OK) ? newsourcep : NULL;
}



TARGETSOURCE *
TargetSource_Create(source, update_spec, collection_id,
		    status, update_spec_old, secondary_source,
		    stat_cache, link_val_cache)
     char *source;
     unsigned update_spec;
     int collection_id;
     unsigned status;
     unsigned update_spec_old;
     TARGETSOURCE *secondary_source;
     FILESTAT *stat_cache;
     char *link_val_cache;
{
  TARGETSOURCE *newsourcep;

  if (source == NULL) {
    FatalError(DEPOT_BADTARGETSOURCEPATH,
	       "Attempt to to create source with NULL source path.\n");
  }
  if (PROGRAM_ErrorNo == OK)
    newsourcep = (TARGETSOURCE *) emalloc(sizeof(TARGETSOURCE));
  if (PROGRAM_ErrorNo == OK) {
    TARGETSOURCE_Path(newsourcep) = String(source, strlen(source));
    /* no error check?  -dkindred */
    TARGETSOURCE_UpdateSpec(newsourcep) = update_spec;
    TARGETSOURCE_CollectionId(newsourcep) = collection_id;
    TARGETSOURCE_Status(newsourcep) = status;
    TARGETSOURCE_OldUpdateSpec(newsourcep) = update_spec_old;
    TARGETSOURCE_SecondarySource(newsourcep)
      = (secondary_source == NULL) ? NULL : TargetSource(secondary_source);
    TARGETSOURCE_LinkValCache(newsourcep)
      = (link_val_cache == NULL) ? 
      NULL : String(link_val_cache, strlen(link_val_cache));
    if (PROGRAM_ErrorNo == OK) {
      TARGETSOURCE_StatCache(newsourcep) = NULL;
      if (stat_cache != NULL) {
	TARGETSOURCE_StatCache(newsourcep)
	  = (FILESTAT *) emalloc(sizeof(FILESTAT));
	if (PROGRAM_ErrorNo == OK) {
	  memcpy(TARGETSOURCE_StatCache(newsourcep), stat_cache, 
		 sizeof(FILESTAT));
	} else {
	  TargetSource_Free(newsourcep);
	}
      }
    }
  }
  return (PROGRAM_ErrorNo == OK) ? newsourcep : NULL;
}

/* $$$NOTE$$$
 * This does not compare the values of the OldUpdateSpec field - a fact which
 * is not in keeping with the general *_Comparator() paradigm used.
 * (It also doesn't compare stat_cache/link_val_cache.)
 */
Boolean 
TargetSource_Comparator(sp1, sp2)
     TARGETSOURCE *sp1, *sp2;
{
  Boolean Comparison;

  if ((sp1 == NULL) && (sp2 == NULL))
    Comparison = TRUE;
  else if ((sp1 == NULL) && (sp2 == NULL)) {	/* one is NULL, but other is not */
    Comparison = FALSE;
  } else {			/* both are non-NULL */
    if (String_Comparator(TARGETSOURCE_Path(sp1),
			  TARGETSOURCE_Path(sp2)) != 0)
      Comparison = FALSE;
    else if (TARGETSOURCE_UpdateSpec(sp1) != TARGETSOURCE_UpdateSpec(sp2))
      Comparison = FALSE;
    else if (TARGETSOURCE_CollectionId(sp1) != TARGETSOURCE_CollectionId(sp2))
      Comparison = FALSE;
    else if (TARGETSOURCE_Status(sp1) != TARGETSOURCE_Status(sp2))
      Comparison = FALSE;
    else if (TargetSource_Comparator(TARGETSOURCE_SecondarySource(sp1),
				     TARGETSOURCE_SecondarySource(sp2))
	     != TRUE)
      Comparison = FALSE;
    else
      Comparison = TRUE;
  }

  return (PROGRAM_ErrorNo == OK) ? Comparison : FALSE;
}



/*
 * $$$$KLUDGE$$$
 * Give me a better name than this!
 *      This is much the same as TargetSource_Comparator(),
 * except in that the U_TARGET update_spec and any status are ignored.
 */
Boolean 
TargetSource_DuplicateComparator(sp1, sp2)
     TARGETSOURCE *sp1, *sp2;
{
  Boolean Comparison;

  if ((sp1 == NULL) && (sp2 == NULL))
    Comparison = TRUE;
  else if ((sp1 == NULL) && (sp2 == NULL)) {	/* one is NULL, but other is not */
    Comparison = FALSE;
  } else {			/* both are non-NULL */
    if (String_Comparator(TARGETSOURCE_Path(sp1),
			  TARGETSOURCE_Path(sp2)) != 0)
      Comparison = FALSE;
    else if ((TARGETSOURCE_UpdateSpec(sp1) & ~U_TARGET)
	     != (TARGETSOURCE_UpdateSpec(sp2) & ~U_TARGET))
      Comparison = FALSE;
    else if (TARGETSOURCE_CollectionId(sp1) != TARGETSOURCE_CollectionId(sp2))
      Comparison = FALSE;
    else if (TargetSource_DuplicateComparator
	     (TARGETSOURCE_SecondarySource(sp1),
	      TARGETSOURCE_SecondarySource(sp2)) != TRUE)
      Comparison = FALSE;
    else
      Comparison = TRUE;
  }

  return (PROGRAM_ErrorNo == OK) ? Comparison : FALSE;
}



void 
TargetSource_Free(sourcep)
     TARGETSOURCE *sourcep;
{
  if (sourcep == NULL) {
    FatalError(DEPOT_BADTARGETSOURCE,
	       "Attempt to free NULL target source.\n");
  } else {
    if (TARGETSOURCE_Path(sourcep) != NULL)
      String_Free(TARGETSOURCE_Path(sourcep));
    if (TARGETSOURCE_SecondarySource(sourcep) != NULL)
      TargetSource_Free(TARGETSOURCE_SecondarySource(sourcep));
    if (TARGETSOURCE_StatCache(sourcep) != NULL)
      free(TARGETSOURCE_StatCache(sourcep));
    if (TARGETSOURCE_LinkValCache(sourcep) != NULL)
      String_Free(TARGETSOURCE_LinkValCache(sourcep));
    (void) free(sourcep);
  }

  return;
}

/* $Source: /afs/andrew.cmu.edu/system/src/local/depot2/032/lib/TargetDB/RCS/SourceUtil.c,v $ */
