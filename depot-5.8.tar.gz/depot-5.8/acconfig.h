/* Define if you are using AFS */
#undef HAVE_AFS

/* define if you want the _BSD compatibility library */
#undef _BSD

/* define if the system uses union wait for the status return value */
#undef HAVE_UNION_WAIT

