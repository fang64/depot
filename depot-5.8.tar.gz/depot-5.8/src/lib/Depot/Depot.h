/***********************************************************
        Copyright 1991,1994 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/


#ifndef _DEPOT_H
#define _DEPOT_H

/* $Id: Depot.h,v 1.7 1994/10/11 15:18:38 ww0r Exp $ */

/*
 * Author: Sohan C. Ramakrishna Pillai
 */


/* modes in which depot could be run */
#define M_NULL                   0x000000
#define M_LOCKONLY               0x000001
#define M_SHOWACTIONSONLY        0x000002
#define M_DELTA                  0x000004
#define M_VERBOSE                0x000020
#define M_IMPLICITLOCKINGALLOWED 0x000100
#define M_USEMODTIMES            0x001000
#define M_NOMODTIMES             0x002000
#define M_KEEPATTRIB             0x010000
#define M_DITCHATTRIB            0x020000
#define M_COMPRESSTDB            0x100000
#define M_NOCOMPRESSTDB          0x200000

extern int Depot();

extern void Depot_RunBuildMode();
extern void Depot_RunDeltaMode();

#endif /* _DEPOT_H */
