#if !defined(SABER) && !defined(LINT)
static char rcs_id[] = "$Id: File_Copy.c,v 1.12 1995/02/08 15:10:30 ww0r Exp $";
#endif /* LINT && SABER */

/*************************************************************************

 cp.c  -- file copying (main routines)
 Copyright (C) 1989, 1990, 1991 Free Software Foundation.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

 The GNU Public License can be found in this directory as 
 COPYING.File_Copy 

 Written by Torbjorn Granlund, David MacKenzie, and Jim Meyering.

 Modified for use in package by John G. Myers

 Modified for use in depot by Sohan C. Ramakrishna Pillai

 *************************************************************************/


#include "depotlib.h"

#include "util.h"
#include "DepotErrorCodes.h"
#include "File.h"
#include "busy.h"

/* Copy a regular file from FROM to TO.  Large blocks of zeroes,
 * as well as holes in the source file, are made into holes in the
 * target file.  (Holes are read as zeroes by the `read' system call.)
 * Return 0 if successful, -1 if an error occurred. */

/* NOTE: The routines to preseve 'holes' in files has been removed as many 
 *       operating systems now cannot deal with holes in executables. If one wishes
 *       to preserve holes in files, one should write a filter to do so. The logic for holes 
 *       was pretty simple: Read in a block of data. If the block of data is full of zero's 
 *       then lseek past the block instead of writing. A file cannot end with a hole so
 *       using ftruncate to 'close' the file is required.
*/
static int
cp(from, to)
     char *from;
     char *to;
{
#define CP_BUFSIZE 8192
/* in general 8192 will be the optimal block size so let's avoid some overhead */
  int target_desc;
  int source_desc;
  register int n_read;
  int n_written;
  int return_val = 0;
  register long n_read_total = 0;
  char buf[CP_BUFSIZE]; 

  source_desc = open(from, O_RDONLY);
  if (source_desc < 0) {
    FatalError(E_COPYFAILED, "Unable to open source file.\n");
    return -1;
  }
  /* Create the new regular file with small permissions initially, to not
   * create a security hole.  */ 
  target_desc = open(to, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (target_desc < 0) {
    FatalError(E_COPYFAILED, "Unable to open target file.\n");
    return_val = -1;
    goto ret2;
  }

  /* Make a buffer with space for a sentinel at the end.  */

  for (;;) {
    n_read = read(source_desc, buf, CP_BUFSIZE);
    if (n_read < 0) {
      FatalError(E_COPYFAILED, "Error reading source file.\n");
      return_val = -1;
      goto ret;
    }
    if (n_read == 0)
      break;

    n_read_total += n_read;

    n_written = write(target_desc, buf, n_read);
    if (n_written < n_read) {
      FatalError(E_COPYFAILED, "Error writing destination file.\n");
      return_val = -1;
      goto ret;
    }
  }

ret:
  if (close(target_desc) < 0) {
    FatalError(E_COPYFAILED, "Error closing target file\n");
    return -1;
  }

ret2:
  if (close(source_desc) < 0) {
    FatalError(E_COPYFAILED, "Error closing source file\n");
    return -1;
  }

  return return_val;
#undef CP_BUFSIZE
} 

int 
File_Copy(from, to, status, flags)
     char *from, *to;
     FILESTAT *status;
     unsigned flags;
{
  FILESTAT statbuf;
  char temp[MAXPATHLEN];

  (void) sprintf(temp, "%s.NEW", to);
  Filtered_Message(PROGRAM_Verbose, "COPY %s %s\n", from, temp);

  if (PROGRAM_ErrorNo == E_NULL) {
    if (cp(from, temp) < 0) {
      FatalError(E_COPYFAILED,
		 "Could not copy %s to %s:%s\n", from, temp,
		 strerror(errno));
    }
  }
  if ((PROGRAM_ErrorNo == E_NULL) && (flags != FSTAT_NULL)) {
    if (status == NULL) {
      status = &statbuf;
      if (File_GetStatus(from, status, FALSE /* !followlinks */ ) < 0) {
	FatalError(E_GETSTATUSFAILED,
		   "Could not get status of file %s\n", from);
      }
    }
    if (PROGRAM_ErrorNo == E_NULL) {
      /* set modes etc. */
      if (File_SetStatus(temp, status, flags) < 0) {
	FatalError(E_SETSTATUSFAILED,
		   "Could not set status of file %s\n", temp);
      }
    }
  }
  if (PROGRAM_ErrorNo == E_NULL) {
    if (File_Move(temp, to) < 0) { 
      FatalError(E_RENAMEFAILED,
		   "\nCOPY %s %s : Could not move %s to %s: %s\n",
		   from, to, temp, to, strerror(errno));
    }
  }
  return ((PROGRAM_ErrorNo == E_NULL) ? 0 : -1);
}

/* $Source: /afs/andrew.cmu.edu/system/src/local/depot2/018/src/lib/FileOps/RCS/File_Copy.c,v $ */
