#ifndef _MASTER_DEPOT_DB_H
#define _MASTER_DEPOT_DB_H

/* $Id: MasterDepotDB.h,v 1.3 1994/06/28 20:13:36 ww0r Exp $ */

/* Note that this provides the interface that was the concatenated
 * DepotDB.h 
 */
#include "DepotConf.h"
#include "TargetDB.h"
#include "Collection.h"
#include "CollectionList.h"
#include "DepotDB.h"
#include "Depot.h"
#include "DepotUtil.h"
#include "Command.h"

extern char * getversion_libdepot();
 
#endif /* _MASTER_DEPOT_DB_H */








