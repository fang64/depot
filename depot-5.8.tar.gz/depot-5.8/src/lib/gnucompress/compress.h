#ifndef _DEPOT_COMPRESS_H
#define _DEPOT_COMPRESS_H

/* $Header: /afs/andrew.cmu.edu/system/src/local/depot2/011/src/lib/gnucompress/RCS/compress.h,v 1.2 1994/04/07 17:35:17 ww0r Exp $ */

/*
 * Author: Sohan C. Ramakrishna Pillai
 */

extern int Compress();
extern int DeCompress();


#endif /* _DEPOT_COMPRESS_H */
