
/* gzip (GNU zip) -- compress files with zip algorithm and 'compress' interface
 * Copyright (C) 1992-1993 Jean-loup Gailly
 * The unzip code was written and put in the public domain by Mark Adler.
 * Portions of the lzw code are derived from the public domain 'compress'
 * written by Spencer Thomas, Joe Orost, James Woods, Jim McKie, Steve Davies,
 * Ken Turkowski, Dave Mack and Peter Jannesen.
 *
 * See the license_msg below and the file COPYING for the software license.
 * See the file algorithm.doc for the compression algorithms and file formats.
 */
/*
 * Modified as function call to be called by a forked child by
 *	Sohan C. Ramakrishna-Pillai (sohan+@andrew.cmu.edu)
 *
 */

#ifndef SABER
#ifndef lint
static char  *license_msg[] = {
"   Copyright (C) 1992-1993 Jean-loup Gailly",
"   The (de)compression routines used in this program",
"   is free software; you can redistribute it and/or modify",
"   it under the terms of the GNU General Public License as published by",
"   the Free Software Foundation; either version 2, or (at your option)",
"   any later version.",
"",
"   The (de)compression routines were distributed in the hope that it will be",
"   useful, but WITHOUT ANY WARRANTY; without even the implied warranty of",
"   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the",
"   GNU General Public License for more details.",
"",
"   To receive a copy of the GNU General Public License, you may write to the",
"   Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.",
0};
#endif
#endif

/* Compress files with zip algorithm and 'compress' interface.
 * See usage() and help() functions below for all options.
 * Outputs:
 *        file.gz:   compressed file with same mode, owner, and utimes
 *     or stdout with -c option or if stdin used as input.
 * If the output file name had to be truncated, the original name is kept
 * in the compressed file.
 * On MSDOS, file.tmp -> file.tmz. On VMS, file.tmp -> file.tmp-gz.
 *
 * Using gz on MSDOS would create too many file name conflicts. For
 * example, foo.txt -> foo.tgz (.tgz must be reserved as shorthand for
 * tar.gz). Similarly, foo.dir and foo.doc would both be mapped to foo.dgz.
 * I also considered 12345678.txt -> 12345txt.gz but this truncates the name
 * too heavily. There is no ideal solution given the MSDOS 8+3 limitation. 
 *
 * For the meaning of all compilation flags, see comments in Makefile.in.
 */

#ifndef SABER
#ifndef lint
static char rcsid[] = "$Id: compress.c,v 1.6 1994/12/16 21:15:12 ww0r Exp $";
#endif
#endif

#include <ctype.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/stat.h>
#include <errno.h>

#include "tailor.h"
#include "gzip.h"
#include "revision.h"
#include "compress.h"

		/* configuration */

#ifdef NO_TIME_H
#  include <sys/time.h>
#else
#  include <time.h>
#endif

#ifndef NO_FCNTL_H
#  include <fcntl.h>
#endif

#ifdef HAVE_UNISTD_H
#  include <unistd.h>
#endif

#if defined(STDC_HEADERS) || !defined(NO_STDLIB_H)
#  include <stdlib.h>
#else
   extern int errno;
#endif

#if defined(DIRENT)
#  include <dirent.h>
   typedef struct dirent dir_type;
#  define NLENGTH(dirent) ((int)strlen((dirent)->d_name))
#  define DIR_OPT "DIRENT"
#else
#  define NLENGTH(dirent) ((dirent)->d_namlen)
#  ifdef SYSDIR
#    include <sys/dir.h>
     typedef struct direct dir_type;
#    define DIR_OPT "SYSDIR"
#  else
#    ifdef SYSNDIR
#      include <sys/ndir.h>
       typedef struct direct dir_type;
#      define DIR_OPT "SYSNDIR"
#    else
#      ifdef NDIR
#        include <ndir.h>
         typedef struct direct dir_type;
#        define DIR_OPT "NDIR"
#      else
#        define NO_DIR
#        define DIR_OPT "NO_DIR"
#      endif
#    endif
#  endif
#endif

#ifndef NO_UTIME
#  ifndef NO_UTIME_H
#    include <utime.h>
#    define TIME_OPT "UTIME"
#  else
#    ifdef HAVE_SYS_UTIME_H
#      include <sys/utime.h>
#      define TIME_OPT "SYS_UTIME"
#    else
       struct utimbuf {
         time_t actime;
         time_t modtime;
       };
#      define TIME_OPT ""
#    endif
#  endif
#else
#  define TIME_OPT "NO_UTIME"
#endif

#if !defined(S_ISDIR) && defined(S_IFDIR)
#  define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)
#endif
#if !defined(S_ISREG) && defined(S_IFREG)
#  define S_ISREG(m) (((m) & S_IFMT) == S_IFREG)
#endif

typedef RETSIGTYPE (*sig_type) OF((int));

#ifndef	O_BINARY
#  define  O_BINARY  0  /* creation mode for open() */
#endif

#ifndef O_CREAT
   /* Pure BSD system? */
#  include <sys/file.h>
#  ifndef O_CREAT
#    define O_CREAT FCREAT
#  endif
#  ifndef O_EXCL
#    define O_EXCL FEXCL
#  endif
#endif

#ifndef S_IRUSR
#  define S_IRUSR 0400
#endif
#ifndef S_IWUSR
#  define S_IWUSR 0200
#endif
#define RW_USER (S_IRUSR | S_IWUSR)  /* creation mode for open() */

#ifndef MAX_PATH_LEN
#  define MAX_PATH_LEN   1024 /* max pathname length */
#endif

#ifndef SEEK_END
#  define SEEK_END 2
#endif

#ifdef NO_OFF_T
  typedef long off_t;
  off_t lseek OF((int fd, off_t offset, int whence));
#endif

/* Separator for file name parts (see shorten_name()) */
#ifdef NO_MULTIPLE_DOTS
#  define PART_SEP "-"
#else
#  define PART_SEP "."
#endif

		/* global buffers */

DECLARE(uch, inbuf,  INBUFSIZ +INBUF_EXTRA);
DECLARE(uch, outbuf, OUTBUFSIZ+OUTBUF_EXTRA);
DECLARE(ush, d_buf,  DIST_BUFSIZE);
DECLARE(uch, window, 2L*WSIZE);
DECLARE(ush, tab_prefix, 1L<<BITS);

		/* local variables */
/* XXX Depot change - hide all variables that aren\'t used by depot */
int to_stdout = 0;    /* output to stdout (-c) */
static int decompress = 0;   /* decompress (-d) */
static int force = 0;        /* don't ask questions, compress links (-f) */
static int no_name = 0;      /* don't save or restore the original file name */
static int verbose = 0;      /* be verbose (-v) */
int quiet = 0;        /* be very quiet (-q) */
int test = 0;         /* test .gz file integrity */
static int foreground;       /* set if program run in foreground */
char *progname;       /* program name */
int method = DEFLATED;/* compression method */
int level = 6;        /* compression level */
int exit_code = OK;   /* program exit code */
static int last_member;      /* set for .zip and .Z files */
static int part_nb;          /* number of parts in .gz file */
long time_stamp;       /* original time stamp (modification time) */
static long ifile_size;      /* input file size, -1 for devices (debug only) */
static char *env;            /* contents of GZIP env variable */
static char **args = NULL;   /* argv pointer if GZIP env variable defined */
static char z_suffix[MAX_SUFFIX+1]; /* default suffix (can be set with --suffix) */
static int  z_len;           /* strlen(z_suffix) */

long bytes_in;             /* number of input bytes */
long bytes_out;            /* number of output bytes */
static struct stat istat;         /* status for input file */
int  ifd;                  /* input file descriptor */
int  ofd;                  /* output file descriptor */
unsigned insize;           /* valid bytes in inbuf */
unsigned inptr;            /* index of next byte to be processed in inbuf */
unsigned outcnt;           /* bytes in output buffer */

/* local functions */

local int compress_action OF((int fdin, int fdout, int decompressflag));
local void treat_input  OF((int fdin, int fdout));
local int  get_method   OF((int in));
local void do_exit      OF((int exitcode));
      int main          OF((int argc, char **argv));

int (*work) OF((int infile, int outfile)) = zip; /* function to call */

#define strequ(s1, s2) (strcmp((s1),(s2)) == 0)

/*
 * int main(argc, argv)
 *     int argc;
 *     char **argv;
 *{
 *  if ((argc > 1) && (strcmp(argv[1], "-d") == 0))
 *    compress(0, 1, 1);
 *  else
 *    compress(0, 1, 0);
 *}
 */

int Compress(fdin, fdout)
     int fdin, fdout;
{
  return compress_action(fdin, fdout, 0 /* decompressflag */);
}


int DeCompress(fdin, fdout)
     int fdin, fdout;
{
  return compress_action(fdin, fdout, 1 /* decompressflag */);
}


/* ======================================================================== */
local int compress_action(fdin, fdout, decompressflag)
     int fdin, fdout;
     int decompressflag;
{
  /*
   * kludgey-kludge, but rather than edit the whole package,
   * set and use the global variables used by this package -- Sohan
   */
  ifd = fdin; ofd = fdout;

    progname = decompressflag? "gnu-compress" : "gnu-decompress";

    decompress = decompressflag? 1 : 0;
    strncpy(z_suffix, Z_SUFFIX, sizeof(z_suffix)-1);
    z_len = strlen(z_suffix);

    force++;
    no_name = 1;
    /* quiet = 1; verbose = 0; */
    /*
     * z_len = strlen(optarg);
     * strcpy(z_suffix, optarg);
     */
    /* verbose++; quiet = 0; */
    /* level = specified level ; */


    if ((z_len == 0 && !decompress) || z_len > MAX_SUFFIX) {
        fprintf(stderr, "%s: incorrect suffix \n",
                progname);
        do_exit(ERROR);
    }

    /* Allocate all global buffers (for DYN_ALLOC option) */
    ALLOC(uch, inbuf,  INBUFSIZ +INBUF_EXTRA);
    ALLOC(uch, outbuf, OUTBUFSIZ+OUTBUF_EXTRA);
    ALLOC(ush, d_buf,  DIST_BUFSIZE);
    ALLOC(uch, window, 2L*WSIZE);
#ifndef MAXSEG_64K
    ALLOC(ush, tab_prefix, 1L<<BITS);
#else
    ALLOC(ush, tab_prefix0, 1L<<(BITS-1));
    ALLOC(ush, tab_prefix1, 1L<<(BITS-1));
#endif

    treat_input(fdin, fdout);

    do_exit(exit_code);
    return exit_code; /* just to avoid lint warning */
}

/* ========================================================================
 * Compress or decompress input
 */
local void treat_input(fdin, fdout)
     int fdin, fdout;
{
    /* Get the time stamp on the input file. */
#ifdef NO_STDIN_FSTAT
    time_stamp = 0; /* time unknown */
#else
    if (fstat(fdin, &istat) != 0) {
	error("fstat(fdin)");
    }
    /* If you do not wish to save the time stamp when input comes from a pipe,
     * compile with -DNO_PIPE_TIMESTAMP.
     */
#ifdef NO_PIPE_TIMESTAMP
    if (!S_ISREG(istat.st_mode))
	time_stamp = 0;
    else
#endif
	time_stamp = istat.st_mtime;
#endif
    ifile_size = -1L; /* convention for unknown size */

    clear_bufs(); /* clear input and output buffers */
    part_nb = 0;

    if (decompress) {
	method = get_method(ifd);
	if (method < 0) {
	    do_exit(exit_code); /* error message already emitted */
	}
    }

    /* Actually do the compression/decompression. Loop over zipped members.
     */
    for (;;) {
	if ((*work)(fdin, fdout) != OK) return;

	if (!decompress || last_member || inptr == insize) break;
	/* end of file */

	method = get_method(ifd);
	if (method < 0) return; /* error message already emitted */
	bytes_out = 0;            /* required for length check */
    }

    if (verbose) {
	if (test) {
	    fprintf(stderr, " OK\n");

	} else if (!decompress) {
	    display_ratio(bytes_in-(bytes_out-header_bytes), bytes_in, stderr);
	    fprintf(stderr, "\n");
#ifdef DISPLAY_STDIN_RATIO
	} else {
	    display_ratio(bytes_out-(bytes_in-header_bytes), bytes_out,stderr);
	    fprintf(stderr, "\n");
#endif
	}
    }
}




/* ========================================================================
 * Check the magic number of the input file
 * Return the compression method, -1 for error, -2 for warning.
 * Set inptr to the offset of the next byte to be processed.
 * This function may be called repeatedly for an input file consisting
 * of several contiguous gzip'ed members.
 * IN assertions: there is at least one remaining compressed member.
 *   If the member is a zip file, it must be the only one.
 */
local int get_method(in)
    int in;        /* input file descriptor */
{
    uch flags;
    char magic[2]; /* magic header */

    /* If --force and --stdout, zcat == cat, so do not complain about
     * premature end of file: use try_byte instead of get_byte.
     */
    if (force && to_stdout) {
	magic[0] = (char)try_byte();
	magic[1] = (char)try_byte();
	/* If try_byte returned EOF, magic[1] == 0xff */
    } else {
	magic[0] = (char)get_byte();
	magic[1] = (char)get_byte();
    }
    time_stamp = istat.st_mtime; /* may be modified later for some methods */
    method = -1;                 /* unknown yet */
    part_nb++;                   /* number of parts in gzip file */
    header_bytes = 0;
    last_member = RECORD_IO;
    /* assume multiple members in gzip file except for record oriented I/O */

    if (memcmp(magic, GZIP_MAGIC, 2) == 0
        || memcmp(magic, OLD_GZIP_MAGIC, 2) == 0) {

	method = (int)get_byte();
	if (method != DEFLATED) {
	    fprintf(stderr,
		    "%s: unknown method %d -- get newer version of gzip\n",
		    progname, method);
	    exit_code = ERROR;
	    return -1;
	}
	work = unzip;
	flags  = (uch)get_byte();

	if ((flags & ENCRYPTED) != 0) {
	    fprintf(stderr,
		    "%s: encrypted -- get newer version of gzip\n",
		    progname);
	    exit_code = ERROR;
	    return -1;
	}
	if ((flags & CONTINUATION) != 0) {
	    fprintf(stderr,
	   "%s: multi-part gzip input -- get newer version of gzip\n",
		    progname);
	    exit_code = ERROR;
	    if (force <= 1) return -1;
	}
	if ((flags & RESERVED) != 0) {
	    fprintf(stderr,
		    "%s: input flags 0x%x -- get newer version of gzip\n",
		    progname, flags);
	    exit_code = ERROR;
	    if (force <= 1) return -1;
	}
	time_stamp  = (ulg)get_byte();
	time_stamp |= ((ulg)get_byte()) << 8;
	time_stamp |= ((ulg)get_byte()) << 16;
	time_stamp |= ((ulg)get_byte()) << 24;

	(void)get_byte();  /* Ignore extra flags for the moment */
	(void)get_byte();  /* Ignore OS type for the moment */

	if ((flags & CONTINUATION) != 0) {
	    unsigned part = (unsigned)get_byte();
	    part |= ((unsigned)get_byte())<<8;
	    if (verbose) {
		fprintf(stderr,"%s: part number %u\n",
			progname, part);
	    }
	}
	if ((flags & EXTRA_FIELD) != 0) {
	    unsigned len = (unsigned)get_byte();
	    len |= ((unsigned)get_byte())<<8;
	    if (verbose) {
		fprintf(stderr,"%s: extra field of %u bytes ignored\n",
			progname, len);
	    }
	    while (len--) (void)get_byte();
	}

	/* Get original file name if it was truncated */
	if ((flags & ORIG_NAME) != 0) {
		/* Discard the old name */
		char c; /* dummy used for NeXTstep 3.0 cc optimizer bug */
		while ((c=get_byte()) != 0) c++;
	} /* ORIG_NAME */

	/* Discard file comment if any */
	if ((flags & COMMENT) != 0) {
	  /* EMPTY */
	  while (get_char() != 0) /* null */ ;
	}
	if (part_nb == 1) {
	    header_bytes = inptr + 2*sizeof(long); /* include crc and size */
	}

    } else if (memcmp(magic, PKZIP_MAGIC, 2) == 0 && inptr == 2
	    && memcmp((char*)inbuf, PKZIP_MAGIC, 4) == 0) {
	/* To simplify the code, we support a zip file when alone only.
         * We are thus guaranteed that the entire local header fits in inbuf.
         */
        inptr = 0;
	work = unzip;
	if (check_zipfile(in) != OK) return -1;
	last_member = 1;

    } else if (force && to_stdout) { /* pass input unchanged */
	method = STORED;
	work = copy;
        inptr = 0;
	last_member = 1;
    }
    if (method >= 0) return method;

    if (part_nb == 1) {
	fprintf(stderr, "\n%s: not in gzip format\n", progname);
	exit_code = ERROR;
	return -1;
    } else {
	WARN((stderr, "\n%s: decompression OK, trailing garbage ignored\n",
	      progname));
	return -2;
    }
}

/* ========================================================================
 * Free all dynamically allocated variables and exit with the given code.
 */
local void do_exit(exitcode)
    int exitcode;
{
    if (env != NULL)  free(env),  env  = NULL;
    if (args != NULL) free((char*)args), args = NULL;
    FREE(inbuf);
    FREE(outbuf);
    FREE(d_buf);
    FREE(window);
#ifndef MAXSEG_64K
    FREE(tab_prefix);
#else
    FREE(tab_prefix0);
    FREE(tab_prefix1);
#endif
    _exit(exitcode); /* call with a fork */
}


/* ========================================================================
 * Signal and error handler.
 */
RETSIGTYPE abort_gzip()
{
   do_exit(ERROR);
}


/*
 * $Log: compress.c,v $
 * Revision 1.6  1994/12/16  21:15:12  ww0r
 * remove the signal handling crap as it interferes with depot's own
 * signal handling (e.g. the default signal handling)
 *
 * Revision 1.5  1994/09/12  15:41:17  ww0r
 * change compress flag to int
 *
 * Revision 1.4  1994/08/07  03:33:35  ww0r
 * removed unused code and variables
 *
 * Revision 1.3  1994/06/28  14:32:40  ww0r
 * hide some global variables
 *
 * Revision 1.2  1994/04/07  16:04:38  ww0r
 * properly protype some functions
 *
 * Revision 1.1  1993/06/29  20:19:07  sohan
 * Initial revision
 *
 * Revision 1.2  1993/06/28  19:38:08  sohan
 * Use _exit since we expect to call this from a forked child process.
 *
 *
 */
