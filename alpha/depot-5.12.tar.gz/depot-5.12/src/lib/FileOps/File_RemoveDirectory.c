/***********************************************************
        Copyright 1991,1994 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/


#ifndef SABER
#ifndef LINT
static char rcs_id[]="$Id: File_RemoveDirectory.c,v 1.4 1994/08/12 14:21:28 ww0r Exp $";
#endif /* LINT */
#endif /* SABER */

/*
 * Author: Sohan C. Ramakrishna Pillai
 */

#include "depotlib.h"

#include "util.h"
#include "DepotErrorCodes.h"
#include "File.h"


int File_RemoveDirectory(path)
     char *path;
{
  Filtered_Message(PROGRAM_Verbose, "REMOVE DIRECTORY %s\n", path);
  if (rmdir(path) < 0)
    {
      FatalError(E_RMDIRFAILED,
		 "Could not remove directory %s: %s\n",  path, strerror(errno));
    }

  return ((PROGRAM_ErrorNo == E_NULL) ? 0 : -1);
}
/* $Source: /afs/andrew.cmu.edu/system/src/local/depot2/011/src/lib/FileOps/RCS/File_RemoveDirectory.c,v $ */
