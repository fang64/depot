#!/usr/local/bin/perl

$ndir = $ARGV[0];
$nfile = $ARGV[1];

print "Generating $ndir directories with $nfile files....\n";
$|=1;				# unbuffer output
for ($i=0;$i<$ndir;$i++) {
  $dname = "gendir-$i";
  mkdir("$dname",0755) || die "Can't create directory: $dname: $!\n";
  for ($j=0;$j<$nfile;$j++) {
    open(FP,">$dname/$i-$j") || die "Can't create file: $dname/$i-$j: $!\n";
    close(FP);
    print "."
      if (($j % 50) == 0);
  }
  print "\n";
}
print "done.\n";
