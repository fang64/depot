static void null() {}
