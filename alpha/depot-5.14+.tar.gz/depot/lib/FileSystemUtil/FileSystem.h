/***********************************************************
        Copyright 1991,1994 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.
******************************************************************/

#ifndef _DEPOT_FILESYSTEM_H
#define _DEPOT_FILESYSTEM_H
/* $Id: FileSystem.h,v 1.4 1994/08/12 17:53:32 ww0r Exp $
 *
 * Author: Sohan C. Ramakrishna Pillai
 */

typedef struct fsinfo
{
  char          *path;          /* path to mountpoint */
  char		*fs_id;		/* volume no. */
  time_t	fs_modtime;	/* volume mod time */
} FSINFO;

extern int FileSystem_Initialize();
extern int FileSystem_End();
extern int FileSystem_GetFSInfo();
 
#endif /* _DEPOT_FILESYSTEM_H */
/* $Source: /afs/andrew.cmu.edu/system/src/local/depot2/022/lib/FileSystemUtil/RCS/FileSystem.h,v $ */
